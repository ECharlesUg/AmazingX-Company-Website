### Design Guidelines for "Amazing Company X" Website

#### General Layout:

- Fixed Page Width: 800px.
- Content Margin: Auto (to center the content on the page).
- Border: 2px solid dark blue around the main content area.

#### Colors:

- Primary Color (used for headers, important text): `#1a1aff` (dark blue).
- Secondary Color (used for navigation and footer background): `#000000` (black).
- Accent Color (used for titles, links on hover): `#6495ed` (cornflower blue).
- Text Color: `#c0c0c0` (silver) for navigation links; `#000000` (black) for regular text.
- Link Hover Effect: Background color changes to cornflower blue with a gentle padding effect.

#### Typography:

- Font Family: Arial, Helvetica, sans-serif for the entire website.
- Homepage Main Title: 36px, bold, dark blue.
- Subtitles/Header 2 (h2): 24px, dark blue.
- Regular Text/Paragraphs: 16px, black.
- Navigation and Footer Text: 14px, silver.

#### Navigation Bar:

- Background Color: Black.
- Text Alignment: Centered.
- Padding: 5px for list items.

#### Company Title Card (on every page):

- Background Color: Cornflower blue.
- Padding: 20px.
- Height: 160px (adjust according to content).
- Text Color: Light blue for titles; white for subtitle or description.
- Title Font Size: 30px; Subtitle or Description Font Size: 18px.

#### Main Content Area:

- Padding: 10px for general content sections.
- Images: Maximum width of 775px to fit within the content area.

#### Tables (products page):

- Margin: 50px 20px.
- Border: 1px solid gray for cells; border-collapse property enabled.
- Odd Rows Background Color: `#99ccff` (light blue).
- Table Header Background Color: White.
- Caption Font Style: Italic, 16px.

#### Form (contact page):

- Text Alignment: Center.
- Input Fields Width: Auto; enough to accommodate typical text entries.
- Margin and Padding: Adequate spacing to avoid a cramped look.

#### Footer:

- Background Color: Cornflower blue.
- Text Alignment: Center.
- Padding: 20px.
